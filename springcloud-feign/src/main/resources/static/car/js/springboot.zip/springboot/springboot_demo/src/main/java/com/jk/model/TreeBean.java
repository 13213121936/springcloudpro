/** 
 * <pre>项目名称:bootstrap 
 * 文件名称:TreeBean.java 
 * 包名:com.jk.wdd.pojo 
 * 创建日期:2019年3月19日下午2:05:28 
 * Copyright (c) 2019, yuxy123@gmail.com All Rights Reserved.</pre> 
 */  
package com.jk.model;

import java.io.Serializable;
import java.util.List;

/** 
 * <pre>项目名称：bootstrap    
 * 类名称：TreeBean    
 * 类描述：    
 * 创建人：wdd   
 * 创建时间：2019年3月19日 下午2:05:28    
 * 修改人：wdd 
 * 修改时间：2019年3月19日 下午2:05:28    
 * 修改备注：       
 * @version </pre>    
 */
public class TreeBean implements Serializable {
	private static final long serialVersionUID = -6789749752378361734L;
	private Integer id;
	private String text;
	private Integer pid;
	private String href;
	private List<TreeBean> nodes;
	private Boolean selectable;//是否可以点击
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getText() {
		return text;
	}
	public void setText(String text) {
		this.text = text;
	}
	public Integer getPid() {
		return pid;
	}
	public void setPid(Integer pid) {
		this.pid = pid;
	}
	public String getHref() {
		return href;
	}
	public void setHref(String href) {
		this.href = href;
	}
	public List<TreeBean> getNodes() {
		return nodes;
	}
	public void setNodes(List<TreeBean> nodes) {
		this.nodes = nodes;
	}
	public Boolean getSelectable() {
		return selectable;
	}
	public void setSelectable(Boolean selectable) {
		this.selectable = selectable;
	}
	
}
