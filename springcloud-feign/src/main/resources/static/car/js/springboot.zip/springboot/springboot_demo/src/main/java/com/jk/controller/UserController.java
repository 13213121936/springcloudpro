package com.jk.controller;

import ch.qos.logback.core.util.FileUtil;
import com.jk.model.*;
import com.jk.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletRequest;
import javax.swing.*;
import java.util.HashMap;
import java.util.List;

@Controller
public class UserController {

    @Autowired
    private UserService userService;

    @RequestMapping("findCarInfo")
    @ResponseBody
    public HashMap<String, Object> findCarInfo(@RequestParam("page") Integer page, @RequestParam("rows") Integer rows) {
        return userService.findCarInfo(page, rows);
    }

    @RequestMapping("findStaff")
    @ResponseBody
    public HashMap<String, Object> findStaff(@RequestParam("page") Integer page, @RequestParam("rows") Integer rows) {
        return userService.findStaff(page, rows);
    }

    @RequestMapping("findCarById")
    @ResponseBody
    public Emp findCarById(@RequestParam("id") Integer id) {
        return userService.findCarById(id);
    }

    @RequestMapping("findTree")
    @ResponseBody
    public List<TreeBean> findTree() {
        return userService.findTree();
    }

    @RequestMapping("findEmp")
    @ResponseBody
    public List<TreeBean> findEmp() {
        return userService.findEmp();
    }


    @RequestMapping("findEmpById")
    @ResponseBody
    public Emp findEmpById(Integer id) {
        return userService.findEmpById(id);
    }

    @RequestMapping("saveUser")
    @ResponseBody
    public void saveUser(Integer qid, Integer yid) {
        userService.saveUser(qid, yid);
    }

    @RequestMapping("findTask")
    @ResponseBody
    public List<Sell> findTask( Integer rows,@RequestParam("id") Integer id) {
        return userService.findTask(id);
    }



    @RequestMapping("findCondition")
    @ResponseBody
    public HashMap<String, Object> findCondition(@RequestParam("page") Integer page, @RequestParam("rows") Integer rows) {
        return userService.findCondition(page, rows);
    }

    @RequestMapping("saveCar")
    @ResponseBody
    public void saveCar(details details) {
         userService.saveCar(details);
    }

    @RequestMapping("saveCars")
    @ResponseBody
    public void saveCars(Car car) {
        userService.saveCars(car);
    }

    @RequestMapping("SaveDetails")
    @ResponseBody
    public void SaveDetails(Detalis detalis) {
        userService.SaveDetails(detalis);
    }

}