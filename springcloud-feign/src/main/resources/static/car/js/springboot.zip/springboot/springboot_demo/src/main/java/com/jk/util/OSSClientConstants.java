package com.jk.util;
 
/**
 * @class:OSSClientConstants
 * @descript:阿里云注册用户基本常量
 * @date:2018年8月18日 下午5:52:34
 * @author sang
 */
public class OSSClientConstants {
	//阿里云API的外网域名//oss-cn-beijing-internal.aliyuncs.com//oss-cn-beijing.aliyuncs.com
    public static final String ENDPOINT = "qiqi5201314.oss-cn-beijing.aliyuncs.com";
    //阿里云API的密钥Access Key ID
    public static final String ACCESS_KEY_ID = "LTAIpvARj9wxS8fm";
    //阿里云API的密钥Access Key Secret
    public static final String ACCESS_KEY_SECRET = "tc7dWzmxhk7PzpuL0PzW6iq6RF8kt8";
    //阿里云API的bucket名称 //wyc-img-data.oss-cn-beijing-internal.aliyuncs.com
    public static final String BACKET_NAME = "qiqi5201314";
    //阿里云API的文件夹名称
    public static final String FOLDER="ygq/";
}
