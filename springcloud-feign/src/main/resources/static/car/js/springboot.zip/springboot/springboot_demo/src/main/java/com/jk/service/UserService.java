package com.jk.service;

import com.jk.model.*;

import java.util.HashMap;
import java.util.List;

public interface UserService {
    HashMap<String, Object> findCarInfo(Integer page, Integer rows);

    HashMap<String, Object> findStaff(Integer page, Integer rows);

    Emp findCarById(Integer id);

    List<TreeBean> findTree();

    List<TreeBean> findEmp();

    Emp findEmpById(Integer id);

    void saveUser(Integer qid, Integer yid);

    List<Sell> findTask(Integer id);

    HashMap<String, Object> findCondition(Integer page, Integer rows);

    void saveCar(details details);

    void saveCars(Car car);

    void SaveDetails(Detalis detalis);

    EmpBean queryUserByName(String username);
}
