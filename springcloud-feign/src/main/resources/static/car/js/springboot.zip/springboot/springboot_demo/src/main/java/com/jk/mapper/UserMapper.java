package com.jk.mapper;

import com.jk.model.*;
import org.apache.ibatis.annotations.Param;

import java.util.List;

public interface UserMapper {
    int findCarInfoCount();

    List<Sell> findCarInfo(@Param("start") int start, @Param("rows")Integer rows);

    int findStaffCount();

    List<Emp> findStaff(@Param("start")int start, @Param("rows") Integer rows);




     Emp findCarById( Integer id);

    List<TreeBean> findTreeByPid(int pid);

    List<TreeBean> findEmp();

    Emp findEmpById(Integer id);

    void saveUser(@Param("qid")Integer qid, @Param("yid") Integer yid);



    List<Sell> findTask(@Param("id")Integer id);

    int findConditionCount();

    List<details> findCondition(@Param("start")int start, @Param("rows") Integer rows);

    void saveCar(details details);

    void saveCars(Car car);

    void SaveDetails(Detalis detalis);

    EmpBean queryUserByName(@Param("username") String username);
}
