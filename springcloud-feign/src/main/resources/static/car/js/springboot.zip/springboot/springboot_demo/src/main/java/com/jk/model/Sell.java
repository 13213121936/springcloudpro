package com.jk.model;

import java.io.Serializable;
import java.util.Date;

public class Sell implements Serializable {
    private static final long serialVersionUID = -6789749752378361734L;
    private Integer id;
    private String  brand;
    private String  mileage;
    private String  address;
    private String  plate;
    private Date    cardtime;
    private Date    vehicle;
    private String  inspectionaddress;

    public static long getSerialVersionUID() {
        return serialVersionUID;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getBrand() {
        return brand;
    }

    public void setBrand(String brand) {
        this.brand = brand;
    }

    public String getMileage() {
        return mileage;
    }

    public void setMileage(String mileage) {
        this.mileage = mileage;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getPlate() {
        return plate;
    }

    public void setPlate(String plate) {
        this.plate = plate;
    }

    public Date getCardtime() {
        return cardtime;
    }

    public void setCardtime(Date cardtime) {
        this.cardtime = cardtime;
    }

    public Date getVehicle() {
        return vehicle;
    }

    public void setVehicle(Date vehicle) {
        this.vehicle = vehicle;
    }

    public String getInspectionaddress() {
        return inspectionaddress;
    }

    public void setInspectionaddress(String inspectionaddress) {
        this.inspectionaddress = inspectionaddress;
    }

    @Override
    public String toString() {
        return "Sell{" +
                "id=" + id +
                ", brand='" + brand + '\'' +
                ", mileage='" + mileage + '\'' +
                ", address='" + address + '\'' +
                ", plate='" + plate + '\'' +
                ", cardtime=" + cardtime +
                ", vehicle=" + vehicle +
                ", inspectionaddress='" + inspectionaddress + '\'' +
                '}';
    }
}
