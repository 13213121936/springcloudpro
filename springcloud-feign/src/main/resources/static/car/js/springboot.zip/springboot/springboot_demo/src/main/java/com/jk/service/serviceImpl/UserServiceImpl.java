package com.jk.service.serviceImpl;

import com.jk.mapper.UserMapper;
import com.jk.model.*;
import com.jk.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.HashMap;
import java.util.List;

@Service
public class UserServiceImpl implements UserService {
    @Autowired
    private UserMapper userMapper;

    @Override
    public HashMap<String, Object> findCarInfo(Integer page, Integer rows) {
        HashMap<String, Object> hashMap = new HashMap<>();
        int total = userMapper.findCarInfoCount();
        int start = (page-1)*rows;
        List<Sell> list = userMapper.findCarInfo(start,rows);
        hashMap.put("total", total);
        hashMap.put("rows", list);
        return hashMap;
    }

    @Override
    public HashMap<String, Object> findStaff(Integer page, Integer rows) {
        HashMap<String, Object> hashMap = new HashMap<>();
        int total = userMapper.findStaffCount();
        int start = (page-1)*rows;
        List<Emp> list = userMapper.findStaff(start,rows);
        hashMap.put("total", total);
        hashMap.put("rows", list);
        return hashMap;
    }

    @Override
    public Emp findCarById(Integer id) {

        return userMapper.findCarById(id);
    }

    @Override
    public List<TreeBean> findTree() {
        int pid = 0;
        List<TreeBean> list = findNodes(pid);
        return list;
    }

    @Override
    public List<TreeBean> findEmp() {
        return userMapper.findEmp();
    }

    @Override
    public Emp findEmpById(Integer id) {
        return userMapper.findEmpById(id);
    }

    @Override
    public void saveUser(Integer qid, Integer yid) {
        userMapper.saveUser(qid,yid);
    }

    @Override
    public List<Sell> findTask(Integer id) {

     return  userMapper.findTask(id);
    }

    @Override
    public HashMap<String, Object> findCondition(Integer page, Integer rows) {
        HashMap<String, Object> hashMap = new HashMap<>();
        int total = userMapper.findConditionCount();
        int start = (page-1)*rows;
        List<details> list = userMapper.findCondition(start,rows);
        hashMap.put("total", total);
        hashMap.put("rows", list);
        return hashMap;
    }

    @Override
    public void saveCar(details details) {
        userMapper.saveCar(details);
    }

    @Override
    public void saveCars(Car car) {
        userMapper.saveCars(car);
    }

    @Override
    public void SaveDetails(Detalis detalis) {
        userMapper.SaveDetails(detalis);
    }

    @Override
    public EmpBean queryUserByName(String username) {
        return userMapper.queryUserByName(username);
    }


    private List<TreeBean> findNodes(int pid) {
        List<TreeBean> list = userMapper.findTreeByPid(pid);
        for (TreeBean treeBean : list) {
            Integer id = treeBean.getId();
            List<TreeBean> nodes = findNodes(id);//[]

            if(nodes.size()<=0){
                //没有子节点，应该点击
                treeBean.setSelectable(true);
            }else{
                treeBean.setNodes(nodes);
                treeBean.setSelectable(false);
            }
        }
        return list;
    }
}

