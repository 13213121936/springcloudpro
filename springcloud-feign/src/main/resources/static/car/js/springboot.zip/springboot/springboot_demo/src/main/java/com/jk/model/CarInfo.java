/**
 * Copyright (C), jk
 * FileName: CarInfo
 * Author:   wyl
 * Date:     2019/4/18 11:09
 * Description:
 * History:
 * <author>          <time>          <version>          <desc>
 * 作者姓名           修改时间           版本号              描述
 */
package com.jk.model;

import java.io.Serializable;
import java.util.Date;

/**
 * 〈一句话功能简述〉<br> 
 * 〈〉
 *
 * @author Lenovo
 * @create 2019/4/18
 * @since 1.0.0
 */
public class CarInfo implements Serializable {

    private static final long serialVersionUID = -6789749752378361734L;

    private Integer carid;//id

    private String carname;//名字

    private String cartype;//品牌

    private Double price;//原价

    private Double currentprice;//现价

    private String img;//详细图片

    private Integer audState ;//审核状态

    private Integer state ;//交易状态

    private String city ;//地区

    public Integer getCarid() {
        return carid;
    }

    public void setCarid(Integer carid) {
        this.carid = carid;
    }

    public String getCarname() {
        return carname;
    }

    public void setCarname(String carname) {
        this.carname = carname;
    }

    public String getCartype() {
        return cartype;
    }

    public void setCartype(String cartype) {
        this.cartype = cartype;
    }

    public Double getPrice() {
        return price;
    }

    public void setPrice(Double price) {
        this.price = price;
    }

    public Double getCurrentprice() {
        return currentprice;
    }

    public void setCurrentprice(Double currentprice) {
        this.currentprice = currentprice;
    }

    public String getImg() {
        return img;
    }

    public void setImg(String img) {
        this.img = img;
    }

    public Integer getAudState() {
        return audState;
    }

    public void setAudState(Integer audState) {
        this.audState = audState;
    }

    public Integer getState() {
        return state;
    }

    public void setState(Integer state) {
        this.state = state;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }
}
