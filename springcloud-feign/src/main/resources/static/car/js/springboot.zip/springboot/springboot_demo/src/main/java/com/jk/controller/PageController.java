package com.jk.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class PageController {
    @RequestMapping("toShenHe")
    public  String toShenHe(){
        return "shenhe";
    }

    @RequestMapping("tostaff")
    public  String tostaff(){
        return "staff";
    }

    @RequestMapping("toCar")
    public  String findCarById(){
        return "car";
    }

    @RequestMapping("toMain")
    public  String toMain(){
        return "main2";
    }

    @RequestMapping("toRenWu")
    public  String toRenWu(){
        return "renwu";
    }

    @RequestMapping("tocondition")
    public  String tocondition(){
        return "condition";
    }


    @RequestMapping("toSaveSells")
    public  String toSaveSells(){
        return "saveSell";
    }


    @RequestMapping("toSaveCar")
    public  String toSaveCar(){
        return "carcheck";
    }

    @RequestMapping("toSaveCars")
    public  String toSaveCars(){
        return "cars";
    }

    @RequestMapping("toSaveDetails")
    public  String toSaveDetails(){
        return "details";
    }

    @RequestMapping("toLogin")
    public  String toLogin(){
        return "login";
    }

    @RequestMapping("toTreePage")
    public  String toTreePage(){
        return "treePage";
    }

    @RequestMapping("403")
    public  String to(){
        return "403";
    }

    @RequestMapping("toKuaijie")
    public  String toKuaijie(){
        return "kuaijie";
    }
}
