package com.jk.model;

import com.fasterxml.jackson.annotation.JsonFormat;
import org.springframework.format.annotation.DateTimeFormat;

import java.io.Serializable;
import java.util.Date;

public class Detalis implements Serializable {
    private static final long serialVersionUID = -6789749752378361734L;

    private Integer id;
    private Integer carid;
    private String  area;
    private String  fT;
    private String  cartype;
    private Double  travel;
    private String  es;
    private String  color;
    private String  imports;
    private String  displacement;
    @DateTimeFormat(pattern = "yyyy-MM-dd") //入参
    @JsonFormat(timezone = "GMT+8", pattern = "yyyy-MM-dd")
    private Date    annualTime;
    @DateTimeFormat(pattern = "yyyy-MM-dd") //入参
    @JsonFormat(timezone = "GMT+8", pattern = "yyyy-MM-dd")
    private Date    regTime;
    @DateTimeFormat(pattern = "yyyy-MM-dd") //入参
    @JsonFormat(timezone = "GMT+8", pattern = "yyyy-MM-dd")
    private Date    insuranceTime;
    private String  speed;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getCarid() {
        return carid;
    }

    public void setCarid(Integer carid) {
        this.carid = carid;
    }

    public String getArea() {
        return area;
    }

    public void setArea(String area) {
        this.area = area;
    }

    public String getfT() {
        return fT;
    }

    public void setfT(String fT) {
        this.fT = fT;
    }

    public String getCartype() {
        return cartype;
    }

    public void setCartype(String cartype) {
        this.cartype = cartype;
    }

    public Double getTravel() {
        return travel;
    }

    public void setTravel(Double travel) {
        this.travel = travel;
    }

    public String getEs() {
        return es;
    }

    public void setEs(String es) {
        this.es = es;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public String getImports() {
        return imports;
    }

    public void setImports(String imports) {
        this.imports = imports;
    }

    public String getDisplacement() {
        return displacement;
    }

    public void setDisplacement(String displacement) {
        this.displacement = displacement;
    }



    public Date getRegTime() {
        return regTime;
    }

    public void setRegTime(Date regTime) {
        this.regTime = regTime;
    }

    public Date getInsuranceTime() {
        return insuranceTime;
    }

    public void setInsuranceTime(Date insuranceTime) {
        this.insuranceTime = insuranceTime;
    }

    public String getSpeed() {
        return speed;
    }

    public void setSpeed(String speed) {
        this.speed = speed;
    }

    public Date getAnnualTime() {
        return annualTime;
    }

    public void setAnnualTime(Date annualTime) {
        this.annualTime = annualTime;
    }


    @Override
    public String toString(){
        return "Detalis{" +
                "id=" + id +
                ", carid=" + carid +
                ", area='" + area + '\'' +
                ", fT='" + fT + '\'' +
                ", cartype='" + cartype + '\'' +
                ", travel=" + travel +
                ", es='" + es + '\'' +
                ", color='" + color + '\'' +
                ", imports='" + imports + '\'' +
                ", displacement='" + displacement + '\'' +
                ", annualTime=" + annualTime +
                ", regTime=" + regTime +
                ", insuranceTime=" + insuranceTime +
                ", speed='" + speed + '\'' +
                '}';
    }
}
